from flask import Blueprint, jsonify, request, current_app
from src.models.user import Document, Template, db
from src.routes.user import token_required
import requests
import json
from datetime import datetime

document_bp = Blueprint('document', __name__)

# Helper function to generate document using AI
def generate_document_with_ai(template, user_inputs):
    """
    Generate document content using AI based on template and user inputs
    """
    try:
        # For zero-capital implementation, we'll use a free tier of an AI service
        # This is a placeholder for the actual API call
        # In production, you would use a proper API key and service
        
        prompt = f"""
        Create a legal document based on the following template:
        {template.template_content}
        
        Using these specific details:
        {json.dumps(user_inputs, indent=2)}
        
        Format the document professionally with proper legal structure.
        Include all necessary sections, clauses, and formatting.
        """
        
        # For demo purposes, we'll generate content locally
        # In production, this would be an API call to an AI service
        content = template.template_content
        
        # Replace placeholders with user inputs
        for key, value in user_inputs.items():
            placeholder = f"{{{{${key}$}}}}"
            content = content.replace(placeholder, str(value))
            
        return {
            "success": True,
            "content": content
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

@document_bp.route('/templates', methods=['GET'])
@token_required
def get_templates(current_user):
    category = request.args.get('category')
    is_premium = request.args.get('is_premium')
    
    query = Template.query
    
    if category:
        query = query.filter_by(category=category)
    
    if is_premium is not None:
        is_premium_bool = is_premium.lower() == 'true'
        query = query.filter_by(is_premium=is_premium_bool)
    
    templates = query.all()
    return jsonify([template.to_dict() for template in templates])

@document_bp.route('/templates/<int:template_id>', methods=['GET'])
@token_required
def get_template(current_user, template_id):
    template = Template.query.get_or_404(template_id)
    
    # Check if user can access premium templates
    if template.is_premium and current_user.subscription_type not in ['basic', 'pro']:
        return jsonify({'message': 'Subscription required to access premium templates'}), 403
    
    return jsonify(template.to_dict())

@document_bp.route('/documents', methods=['GET'])
@token_required
def get_documents(current_user):
    documents = Document.query.filter_by(user_id=current_user.id).all()
    return jsonify([doc.to_dict() for doc in documents])

@document_bp.route('/documents/<int:document_id>', methods=['GET'])
@token_required
def get_document(current_user, document_id):
    document = Document.query.get_or_404(document_id)
    
    # Ensure user can only access their own documents
    if document.user_id != current_user.id and not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
    
    return jsonify(document.to_dict())

@document_bp.route('/documents', methods=['POST'])
@token_required
def create_document(current_user):
    data = request.json
    
    # Check if required fields are present
    if not all(k in data for k in ('template_id', 'title', 'inputs')):
        return jsonify({'message': 'Missing required fields'}), 400
    
    # Check if user has remaining documents
    if current_user.get_remaining_documents() <= 0:
        return jsonify({'message': 'Document limit reached. Please upgrade your subscription.'}), 403
    
    # Get the template
    template = Template.query.get_or_404(data['template_id'])
    
    # Check if user can access premium templates
    if template.is_premium and current_user.subscription_type not in ['basic', 'pro']:
        return jsonify({'message': 'Subscription required to access premium templates'}), 403
    
    # Generate document content using AI
    result = generate_document_with_ai(template, data['inputs'])
    
    if not result['success']:
        return jsonify({'message': 'Failed to generate document', 'error': result['error']}), 500
    
    # Create new document
    document = Document(
        user_id=current_user.id,
        title=data['title'],
        document_type=template.category,
        content=result['content']
    )
    
    # Update user's document count
    current_user.documents_generated += 1
    
    # If user is on free trial and has used all documents, mark trial as used
    if current_user.subscription_type == 'free_trial' and current_user.get_remaining_documents() <= 0:
        current_user.free_trial_used = True
    
    db.session.add(document)
    db.session.commit()
    
    return jsonify({
        'message': 'Document created successfully',
        'document': document.to_dict(),
        'documents_remaining': current_user.get_remaining_documents()
    }), 201

@document_bp.route('/documents/<int:document_id>', methods=['PUT'])
@token_required
def update_document(current_user, document_id):
    document = Document.query.get_or_404(document_id)
    
    # Ensure user can only update their own documents
    if document.user_id != current_user.id and not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
    
    data = request.json
    
    if 'title' in data:
        document.title = data['title']
    
    if 'content' in data:
        document.content = data['content']
    
    document.last_modified = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'message': 'Document updated successfully',
        'document': document.to_dict()
    })

@document_bp.route('/documents/<int:document_id>', methods=['DELETE'])
@token_required
def delete_document(current_user, document_id):
    document = Document.query.get_or_404(document_id)
    
    # Ensure user can only delete their own documents
    if document.user_id != current_user.id and not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
    
    db.session.delete(document)
    db.session.commit()
    
    return jsonify({'message': 'Document deleted successfully'}), 200

@document_bp.route('/templates/seed', methods=['POST'])
@token_required
def seed_templates(current_user):
    # Only admin users can seed templates
    if not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
    
    # Sample templates for different categories
    templates = [
        # Freelancer templates
        {
            'name': 'Basic Freelance Contract',
            'category': 'freelancer',
            'description': 'A simple contract for freelance work',
            'is_premium': False,
            'template_content': """
FREELANCE SERVICES AGREEMENT

This Freelance Services Agreement (the "Agreement") is entered into as of {{$date$}} (the "Effective Date") by and between:

CLIENT: {{$client_name$}}, with a principal place of business at {{$client_address$}} ("Client")

FREELANCER: {{$freelancer_name$}}, with a principal place of business at {{$freelancer_address$}} ("Freelancer")

1. SERVICES
Freelancer agrees to perform the following services for Client (the "Services"):
{{$services_description$}}

2. PAYMENT
Client agrees to pay Freelancer the following compensation for the Services:
Amount: {{$payment_amount$}}
Payment Schedule: {{$payment_schedule$}}
Payment Method: {{$payment_method$}}

3. TERM
This Agreement shall commence on the Effective Date and shall continue until {{$end_date$}} or until the Services are completed, whichever is earlier, unless terminated earlier as provided herein.

4. INTELLECTUAL PROPERTY
All work product created by Freelancer in connection with the Services shall be the property of Client upon payment in full.

5. INDEPENDENT CONTRACTOR STATUS
Freelancer is an independent contractor, and neither Freelancer nor Freelancer's staff is, or shall be deemed, Client's employees.

6. CONFIDENTIALITY
Freelancer agrees to keep confidential all information provided by Client.

7. GOVERNING LAW
This Agreement shall be governed by the laws of {{$governing_law$}}.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date.

CLIENT:
{{$client_name$}}
Signature: ________________________
Date: ________________________

FREELANCER:
{{$freelancer_name$}}
Signature: ________________________
Date: ________________________
"""
        },
        {
            'name': 'Non-Disclosure Agreement',
            'category': 'freelancer',
            'description': 'Protect your confidential information when working with clients',
            'is_premium': False,
            'template_content': """
NON-DISCLOSURE AGREEMENT

This Non-Disclosure Agreement (the "Agreement") is entered into as of {{$date$}} by and between:

DISCLOSING PARTY: {{$disclosing_party$}}, with a principal place of business at {{$disclosing_address$}} ("Disclosing Party")

RECEIVING PARTY: {{$receiving_party$}}, with a principal place of business at {{$receiving_address$}} ("Receiving Party")

1. PURPOSE
The parties wish to explore a business opportunity of mutual interest, and in connection with this opportunity, Disclosing Party may disclose to Receiving Party certain confidential information.

2. CONFIDENTIAL INFORMATION
"Confidential Information" means any information disclosed by Disclosing Party to Receiving Party, either directly or indirectly, in writing, orally or by inspection of tangible objects, that is designated as "Confidential," "Proprietary" or some similar designation, or that should reasonably be understood to be confidential given the nature of the information and the circumstances of disclosure.

3. NON-DISCLOSURE AND NON-USE
Receiving Party agrees not to use any Confidential Information for any purpose except to evaluate and engage in discussions concerning a potential business relationship between the parties. Receiving Party agrees not to disclose any Confidential Information to third parties or to its employees, except to those employees who are required to have the information in order to evaluate or engage in discussions concerning the contemplated business relationship.

4. TERM
This Agreement shall remain in effect for a period of {{$term_length$}} from the Effective Date.

5. GOVERNING LAW
This Agreement shall be governed by the laws of {{$governing_law$}}.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the date first written above.

DISCLOSING PARTY:
{{$disclosing_party$}}
Signature: ________________________
Date: ________________________

RECEIVING PARTY:
{{$receiving_party$}}
Signature: ________________________
Date: ________________________
"""
        },
        # Tenant templates
        {
            'name': 'Maintenance Request Letter',
            'category': 'tenant',
            'description': 'Request repairs or maintenance from your landlord',
            'is_premium': False,
            'template_content': """
MAINTENANCE REQUEST LETTER

{{$tenant_name$}}
{{$tenant_address$}}
{{$date$}}

{{$landlord_name$}}
{{$landlord_address$}}

RE: Request for Repairs at {{$property_address$}}

Dear {{$landlord_name$}},

I am writing to formally request repairs for the following issue(s) at my rental property located at {{$property_address$}}:

{{$repair_description$}}

This issue began on or around {{$issue_date$}}. It is affecting my ability to fully use and enjoy the premises in the following ways:

{{$impact_description$}}

According to state law and our lease agreement, landlords are required to maintain rental properties in a habitable condition and make necessary repairs within a reasonable timeframe.

I would appreciate if you could address this issue by {{$requested_completion_date$}}. Please contact me at {{$tenant_phone$}} or {{$tenant_email$}} to arrange a convenient time for the repairs to be made.

If I do not hear from you within {{$response_timeframe$}} days, I will consider pursuing other remedies available under {{$state$}} law.

Thank you for your prompt attention to this matter.

Sincerely,

{{$tenant_name$}}
Tenant
"""
        },
        {
            'name': 'Notice of Lease Violation to Landlord',
            'category': 'tenant',
            'description': 'Notify your landlord of lease violations',
            'is_premium': False,
            'template_content': """
NOTICE OF LEASE VIOLATION

{{$tenant_name$}}
{{$tenant_address$}}
{{$date$}}

{{$landlord_name$}}
{{$landlord_address$}}

RE: Lease Violation at {{$property_address$}}

Dear {{$landlord_name$}},

I am writing to inform you of a lease violation that has occurred at my rental property located at {{$property_address$}}.

According to our lease agreement dated {{$lease_date$}}, specifically section {{$lease_section$}}, you are obligated to:

{{$lease_obligation$}}

However, the following violation has occurred:

{{$violation_description$}}

This violation began on {{$violation_date$}} and has continued for {{$violation_duration$}}. This has impacted me in the following ways:

{{$impact_description$}}

I request that you remedy this violation by {{$remedy_date$}} by taking the following actions:

{{$requested_remedy$}}

If this matter is not resolved by the date specified above, I will be forced to pursue the following remedies available to me under {{$state$}} law:

1. Withholding rent
2. Repairing and deducting costs from rent
3. Breaking the lease without penalty
4. Seeking damages in small claims court
5. Filing a complaint with local housing authorities

Please contact me at {{$tenant_phone$}} or {{$tenant_email$}} to discuss this matter further.

Sincerely,

{{$tenant_name$}}
Tenant
"""
        },
        # Debt templates
        {
            'name': 'Debt Validation Letter',
            'category': 'debt',
            'description': 'Request validation of a debt from a collector',
            'is_premium': False,
            'template_content': """
DEBT VALIDATION LETTER

{{$debtor_name$}}
{{$debtor_address$}}
{{$date$}}

{{$collector_name$}}
{{$collector_address$}}

RE: Account Number: {{$account_number$}}
    Alleged Amount Due: {{$alleged_amount$}}

To Whom It May Concern:

I am writing in response to your {{$communication_type$}} dated {{$communication_date$}}, (copy attached) regarding an alleged debt.

I dispute this debt and, pursuant to the Fair Debt Collection Practices Act (FDCPA), 15 U.S.C. § 1692g, I am requesting validation of this debt. Specifically, I request that you provide me with the following information:

1. The name and address of the original creditor, if different from the current creditor;
2. The complete account number with the original creditor;
3. The date of the last payment made on this account;
4. The date this account was charged off or sold to a third party;
5. A copy of the last billing statement sent to me by the original creditor;
6. A copy of the signed agreement that created this debt;
7. Documentation showing you are licensed to collect debts in {{$state$}};
8. Documentation showing your legal authority to collect this debt.

Under the FDCPA, you are required to cease all collection activities until you have provided the requested validation. This includes reporting this debt to any credit reporting agencies.

If you fail to respond to this validation request within 30 days, as required by the FDCPA, your continued collection efforts will be considered a violation of federal law.

Please send the requested information to my address listed above.

Sincerely,

{{$debtor_name$}}

cc: Consumer Financial Protection Bureau
    Federal Trade Commission
"""
        },
        # Gig worker templates
        {
            'name': 'Gig Worker Service Agreement',
            'category': 'gig_worker',
            'description': 'Agreement for gig economy workers',
            'is_premium': False,
            'template_content': """
GIG WORKER SERVICE AGREEMENT

This Gig Worker Service Agreement (the "Agreement") is entered into as of {{$date$}} (the "Effective Date") by and between:

CLIENT: {{$client_name$}}, with a principal place of business at {{$client_address$}} ("Client")

GIG WORKER: {{$worker_name$}}, with a principal place of business at {{$worker_address$}} ("Worker")

1. SERVICES
Worker agrees to perform the following services for Client (the "Services"):
{{$services_description$}}

2. PAYMENT
Client agrees to pay Worker the following compensation for the Services:
Rate: {{$payment_rate$}}
Payment Schedule: {{$payment_schedule$}}
Payment Method: {{$payment_method$}}

3. TERM
This Agreement shall commence on the Effective Date and shall continue until {{$end_date$}} or until the Services are completed, whichever is earlier, unless terminated earlier as provided herein.

4. INDEPENDENT CONTRACTOR STATUS
Worker is an independent contractor, and neither Worker nor Worker's staff is, or shall be deemed, Client's employees. Worker is responsible for all taxes, insurance, and other obligations related to Worker's business.

5. EQUIPMENT AND EXPENSES
Worker shall be responsible for providing all equipment, tools, and materials necessary to perform the Services. Worker shall be responsible for all expenses incurred in performing the Services unless otherwise agreed in writing.

6. CANCELLATION POLICY
{{$cancellation_policy$}}

7. GOVERNING LAW
This Agreement shall be governed by the laws of {{$governing_law$}}.

IN WITNESS WHEREOF, the parties have executed this Agreement as of the Effective Date.

CLIENT:
{{$client_name$}}
Signature: ________________________
Date: ________________________

WORKER:
{{$worker_name$}}
Signature: ________________________
Date: ________________________
"""
        }
    ]
    
    # Add templates to database
    for template_data in templates:
        template = Template(**template_data)
        db.session.add(template)
    
    db.session.commit()
    
    return jsonify({'message': f'{len(templates)} templates added successfully'}), 201
