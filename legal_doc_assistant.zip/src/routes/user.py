from flask import Blueprint, jsonify, request, session, current_app
from src.models.user import User, db
from werkzeug.security import check_password_hash
import jwt
from datetime import datetime, timedelta
from functools import wraps

user_bp = Blueprint('user', __name__)

# Authentication decorator
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        
        if not token:
            return jsonify({'message': 'Token is missing!'}), 401
        
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query.get(data['user_id'])
            if not current_user:
                return jsonify({'message': 'User not found!'}), 401
        except:
            return jsonify({'message': 'Token is invalid!'}), 401
            
        return f(current_user, *args, **kwargs)
    
    return decorated

@user_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    
    # Check if required fields are present
    if not all(k in data for k in ('username', 'email', 'password')):
        return jsonify({'message': 'Missing required fields'}), 400
    
    # Check if user already exists
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'message': 'Username already exists'}), 400
    
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'Email already exists'}), 400
    
    # Create new user
    user = User(
        username=data['username'],
        email=data['email'],
        password=data['password']
    )
    
    db.session.add(user)
    db.session.commit()
    
    return jsonify({
        'message': 'User registered successfully',
        'user': user.to_dict()
    }), 201

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    
    if not all(k in data for k in ('email', 'password')):
        return jsonify({'message': 'Missing email or password'}), 400
    
    user = User.query.filter_by(email=data['email']).first()
    
    if not user or not user.check_password(data['password']):
        return jsonify({'message': 'Invalid email or password'}), 401
    
    # Generate JWT token
    token = jwt.encode({
        'user_id': user.id,
        'exp': datetime.utcnow() + timedelta(hours=24)
    }, current_app.config['SECRET_KEY'], algorithm="HS256")
    
    return jsonify({
        'message': 'Login successful',
        'token': token,
        'user': user.to_dict()
    })

@user_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    return jsonify(current_user.to_dict())

@user_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.json
    
    if 'username' in data:
        # Check if username is already taken by another user
        existing_user = User.query.filter_by(username=data['username']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Username already exists'}), 400
        current_user.username = data['username']
    
    if 'email' in data:
        # Check if email is already taken by another user
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != current_user.id:
            return jsonify({'message': 'Email already exists'}), 400
        current_user.email = data['email']
    
    if 'password' in data:
        current_user.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify({
        'message': 'Profile updated successfully',
        'user': current_user.to_dict()
    })

@user_bp.route('/subscription', methods=['GET'])
@token_required
def get_subscription(current_user):
    return jsonify({
        'subscription_type': current_user.subscription_type,
        'subscription_active': current_user.is_subscription_active(),
        'subscription_end': current_user.subscription_end.isoformat() if current_user.subscription_end else None,
        'documents_remaining': current_user.get_remaining_documents()
    })

@user_bp.route('/users', methods=['GET'])
@token_required
def get_users(current_user):
    # Only admin users can access all users
    if not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
        
    users = User.query.all()
    return jsonify([user.to_dict() for user in users])

@user_bp.route('/users/<int:user_id>', methods=['GET'])
@token_required
def get_user(current_user, user_id):
    # Users can only access their own data unless they're admin
    if current_user.id != user_id and not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
        
    user = User.query.get_or_404(user_id)
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['PUT'])
@token_required
def update_user(current_user, user_id):
    # Users can only update their own data unless they're admin
    if current_user.id != user_id and not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
        
    user = User.query.get_or_404(user_id)
    data = request.json
    
    if 'username' in data:
        user.username = data['username']
    if 'email' in data:
        user.email = data['email']
    if 'password' in data and current_user.is_admin:
        user.set_password(data['password'])
    if 'is_admin' in data and current_user.is_admin:
        user.is_admin = data['is_admin']
    if 'subscription_type' in data and current_user.is_admin:
        user.subscription_type = data['subscription_type']
        
        # Update subscription dates based on type
        if data['subscription_type'] != 'none':
            user.subscription_start = datetime.utcnow()
            if data['subscription_type'] == 'free_trial':
                user.subscription_end = datetime.utcnow() + timedelta(days=7)
            else:
                user.subscription_end = datetime.utcnow() + timedelta(days=30)
    
    db.session.commit()
    return jsonify(user.to_dict())

@user_bp.route('/users/<int:user_id>', methods=['DELETE'])
@token_required
def delete_user(current_user, user_id):
    # Only admin users can delete users
    if not current_user.is_admin:
        return jsonify({'message': 'Unauthorized'}), 403
        
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    return '', 204
