from flask import Blueprint, jsonify, request, current_app, url_for, redirect
from src.models.user import User, Payment, db
from src.routes.user import token_required
from datetime import datetime, timedelta
import requests
import json
import uuid
import os

payment_bp = Blueprint('payment', __name__)

# PayPal sandbox credentials (for zero-capital implementation)
PAYPAL_CLIENT_ID = os.getenv('PAYPAL_CLIENT_ID', 'sb-client-id')  # Replace with actual sandbox client ID
PAYPAL_CLIENT_SECRET = os.getenv('PAYPAL_CLIENT_SECRET', 'sb-client-secret')  # Replace with actual sandbox secret
PAYPAL_API_BASE = 'https://api-m.sandbox.paypal.com'  # Sandbox URL

# Subscription plans
SUBSCRIPTION_PLANS = {
    'basic': {
        'name': 'Basic Plan',
        'description': 'Access to standard templates and 10 documents per month',
        'price': 29.00,
        'duration_days': 30
    },
    'pro': {
        'name': 'Pro Plan',
        'description': 'Unlimited documents and access to all premium templates',
        'price': 49.00,
        'duration_days': 30
    }
}

# Single-use options
SINGLE_USE_OPTIONS = {
    'single_document': {
        'name': 'Single Document',
        'description': 'Generate one legal document',
        'price': 9.99
    },
    'document_pack_small': {
        'name': 'Small Document Pack',
        'description': '3 legal documents',
        'price': 24.99
    },
    'document_pack_large': {
        'name': 'Large Document Pack',
        'description': '10 legal documents',
        'price': 69.99
    }
}

def get_paypal_access_token():
    """Get PayPal OAuth access token"""
    try:
        # For zero-capital implementation, we'll simulate this
        # In production, you would use actual PayPal API
        return "simulated_access_token_for_sandbox"
    except Exception as e:
        print(f"Error getting PayPal access token: {str(e)}")
        return None

def create_paypal_order(product_name, amount, currency='USD'):
    """Create a PayPal order"""
    try:
        # For zero-capital implementation, we'll simulate this
        # In production, you would use actual PayPal API
        order_id = f"SIMULATED-{uuid.uuid4()}"
        approval_url = f"/payment/simulate-paypal-approval/{order_id}"
        
        return {
            "id": order_id,
            "status": "CREATED",
            "links": [
                {
                    "href": approval_url,
                    "rel": "approve",
                    "method": "GET"
                }
            ]
        }
    except Exception as e:
        print(f"Error creating PayPal order: {str(e)}")
        return None

def capture_paypal_order(order_id):
    """Capture an approved PayPal order"""
    try:
        # For zero-capital implementation, we'll simulate this
        # In production, you would use actual PayPal API
        return {
            "id": order_id,
            "status": "COMPLETED"
        }
    except Exception as e:
        print(f"Error capturing PayPal order: {str(e)}")
        return None

@payment_bp.route('/plans', methods=['GET'])
def get_subscription_plans():
    """Get available subscription plans"""
    return jsonify({
        'subscription_plans': SUBSCRIPTION_PLANS,
        'single_use_options': SINGLE_USE_OPTIONS
    })

@payment_bp.route('/create-subscription', methods=['POST'])
@token_required
def create_subscription(current_user):
    """Create a subscription payment"""
    data = request.json
    
    if 'plan_id' not in data:
        return jsonify({'message': 'Missing plan_id'}), 400
    
    plan_id = data['plan_id']
    if plan_id not in SUBSCRIPTION_PLANS:
        return jsonify({'message': 'Invalid plan ID'}), 400
    
    plan = SUBSCRIPTION_PLANS[plan_id]
    
    # Create PayPal order
    order = create_paypal_order(plan['name'], plan['price'])
    if not order:
        return jsonify({'message': 'Failed to create payment'}), 500
    
    # Create payment record
    payment = Payment(
        user_id=current_user.id,
        payment_type='subscription',
        amount=plan['price'],
        currency='USD',
        payment_method='paypal',
        transaction_id=order['id'],
        status='pending'
    )
    
    db.session.add(payment)
    db.session.commit()
    
    # Find approval URL
    approval_url = next((link['href'] for link in order['links'] if link['rel'] == 'approve'), None)
    
    return jsonify({
        'message': 'Subscription payment created',
        'payment_id': payment.id,
        'order_id': order['id'],
        'approval_url': approval_url
    })

@payment_bp.route('/create-single-purchase', methods=['POST'])
@token_required
def create_single_purchase(current_user):
    """Create a single-use purchase payment"""
    data = request.json
    
    if 'option_id' not in data:
        return jsonify({'message': 'Missing option_id'}), 400
    
    option_id = data['option_id']
    if option_id not in SINGLE_USE_OPTIONS:
        return jsonify({'message': 'Invalid option ID'}), 400
    
    option = SINGLE_USE_OPTIONS[option_id]
    
    # Create PayPal order
    order = create_paypal_order(option['name'], option['price'])
    if not order:
        return jsonify({'message': 'Failed to create payment'}), 500
    
    # Create payment record
    payment = Payment(
        user_id=current_user.id,
        payment_type='one_time',
        amount=option['price'],
        currency='USD',
        payment_method='paypal',
        transaction_id=order['id'],
        status='pending'
    )
    
    db.session.add(payment)
    db.session.commit()
    
    # Find approval URL
    approval_url = next((link['href'] for link in order['links'] if link['rel'] == 'approve'), None)
    
    return jsonify({
        'message': 'Single purchase payment created',
        'payment_id': payment.id,
        'order_id': order['id'],
        'approval_url': approval_url
    })

@payment_bp.route('/simulate-paypal-approval/<order_id>', methods=['GET'])
def simulate_paypal_approval(order_id):
    """Simulate PayPal approval (for zero-capital implementation)"""
    return redirect(url_for('payment.payment_success', order_id=order_id))

@payment_bp.route('/success', methods=['GET'])
def payment_success():
    """Handle successful payment"""
    order_id = request.args.get('order_id')
    if not order_id:
        return jsonify({'message': 'Missing order ID'}), 400
    
    # Find payment record
    payment = Payment.query.filter_by(transaction_id=order_id).first()
    if not payment:
        return jsonify({'message': 'Payment not found'}), 404
    
    # Capture the order
    capture_result = capture_paypal_order(order_id)
    if not capture_result or capture_result['status'] != 'COMPLETED':
        return jsonify({'message': 'Failed to capture payment'}), 500
    
    # Update payment status
    payment.status = 'completed'
    
    # Update user subscription or document credits
    user = User.query.get(payment.user_id)
    
    if payment.payment_type == 'subscription':
        # Find which plan was purchased based on amount
        plan_id = next((plan_id for plan_id, plan in SUBSCRIPTION_PLANS.items() 
                        if plan['price'] == payment.amount), None)
        
        if plan_id:
            user.subscription_type = plan_id
            user.subscription_start = datetime.utcnow()
            user.subscription_end = datetime.utcnow() + timedelta(days=SUBSCRIPTION_PLANS[plan_id]['duration_days'])
    
    elif payment.payment_type == 'one_time':
        # Find which option was purchased based on amount
        option_id = next((option_id for option_id, option in SINGLE_USE_OPTIONS.items() 
                          if option['price'] == payment.amount), None)
        
        if option_id == 'single_document':
            user.documents_generated -= 1  # Credit one document
        elif option_id == 'document_pack_small':
            user.documents_generated -= 3  # Credit three documents
        elif option_id == 'document_pack_large':
            user.documents_generated -= 10  # Credit ten documents
    
    db.session.commit()
    
    return jsonify({
        'message': 'Payment successful',
        'payment': payment.to_dict(),
        'user': user.to_dict()
    })

@payment_bp.route('/webhook', methods=['POST'])
def payment_webhook():
    """Handle PayPal webhooks"""
    # In a production environment, you would verify the webhook signature
    # and process various event types
    
    # For zero-capital implementation, we'll keep this simple
    return jsonify({'message': 'Webhook received'}), 200

@payment_bp.route('/activate-free-trial', methods=['POST'])
@token_required
def activate_free_trial(current_user):
    """Activate free trial for a user"""
    if current_user.free_trial_used:
        return jsonify({'message': 'Free trial already used'}), 400
    
    current_user.subscription_type = 'free_trial'
    current_user.subscription_start = datetime.utcnow()
    current_user.subscription_end = datetime.utcnow() + timedelta(days=7)  # 7-day free trial
    current_user.documents_generated = 0  # Reset document count for trial
    
    db.session.commit()
    
    return jsonify({
        'message': 'Free trial activated successfully',
        'user': current_user.to_dict()
    })
