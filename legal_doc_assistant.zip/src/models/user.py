from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_admin = db.Column(db.Boolean, default=False)
    
    # Subscription related fields
    subscription_type = db.Column(db.String(20), default='free_trial')  # free_trial, basic, pro, none
    subscription_start = db.Column(db.DateTime, nullable=True)
    subscription_end = db.Column(db.DateTime, nullable=True)
    
    # Free trial tracking
    free_trial_used = db.Column(db.Boolean, default=False)
    documents_generated = db.Column(db.Integer, default=0)
    
    def __init__(self, username, email, password, is_admin=False):
        self.username = username
        self.email = email
        self.set_password(password)
        self.is_admin = is_admin
        
        # Set up free trial by default
        self.subscription_type = 'free_trial'
        self.subscription_start = datetime.utcnow()
        self.subscription_end = datetime.utcnow() + timedelta(days=7)  # 7-day free trial
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def is_subscription_active(self):
        if self.subscription_type == 'none':
            return False
        
        if self.subscription_type == 'free_trial':
            return not self.free_trial_used and self.subscription_end > datetime.utcnow()
            
        return self.subscription_end and self.subscription_end > datetime.utcnow()
    
    def get_remaining_documents(self):
        if self.subscription_type == 'free_trial':
            return 3 - self.documents_generated  # 3 free documents during trial
        elif self.subscription_type == 'basic':
            return 10 - (self.documents_generated % 10)  # 10 documents per month
        elif self.subscription_type == 'pro':
            return float('inf')  # Unlimited documents
        else:
            return 0  # No subscription
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'subscription_type': self.subscription_type,
            'subscription_active': self.is_subscription_active(),
            'subscription_end': self.subscription_end.isoformat() if self.subscription_end else None,
            'documents_remaining': self.get_remaining_documents()
        }

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    document_type = db.Column(db.String(50), nullable=False)  # contract, letter, etc.
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_modified = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    user = db.relationship('User', backref=db.backref('documents', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'document_type': self.document_type,
            'content': self.content,
            'created_at': self.created_at.isoformat(),
            'last_modified': self.last_modified.isoformat()
        }

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    payment_type = db.Column(db.String(20), nullable=False)  # subscription, one_time
    amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), default='USD')
    payment_method = db.Column(db.String(20), nullable=False)  # paypal, etc.
    transaction_id = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), default='pending')  # pending, completed, failed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationship
    user = db.relationship('User', backref=db.backref('payments', lazy=True))
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'payment_type': self.payment_type,
            'amount': self.amount,
            'currency': self.currency,
            'payment_method': self.payment_method,
            'transaction_id': self.transaction_id,
            'status': self.status,
            'created_at': self.created_at.isoformat()
        }

class Template(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    category = db.Column(db.String(50), nullable=False)  # freelancer, tenant, etc.
    description = db.Column(db.Text, nullable=True)
    template_content = db.Column(db.Text, nullable=False)
    is_premium = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'category': self.category,
            'description': self.description,
            'is_premium': self.is_premium,
            'created_at': self.created_at.isoformat()
        }
